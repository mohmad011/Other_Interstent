# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 4.x.x   | :white_check_mark: |

## Reporting a Vulnerability

You can open an Issue ticket if you found any security problem or if you have any problem.